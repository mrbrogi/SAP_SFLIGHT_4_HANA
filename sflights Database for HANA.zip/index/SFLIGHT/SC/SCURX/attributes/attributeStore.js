{
  "5": {
    "type": 73,
    "flags": 16385,
    "realName": "$trex_udiv$"},
  "7": {
    "type": 66,
    "flags": 134217745,
    "realName": "$rowid$",
    "intDigits": 18},
  "201": {
    "type": 83,
    "flags": 17,
    "realName": "CURRKEY"},
  "202": {
    "type": 73,
    "flags": 1,
    "realName": "CURRDEC"}}